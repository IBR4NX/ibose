export function useCard() {
  return {};
}
